import { StyleSheet, Text, View } from 'react-native';
import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { NavigationContainer } from '@react-navigation/native';
// You can import supported modules from npm
import { Card } from 'react-native-paper';
import HomeScreen from './screens/HomeScreen';
import ColorSelectScreen from './screens/ColorSelectScreen';
import ConfirmScreen from './screens/ConfirmScreen';
import FinalScreen from './screens/FinalScreen';

// or any files within the Snack

// export type RootStackParamList = {
//   Home: undefined;
//   ColorSelect: undefined;
//   Confirm: { color: string };
//   Final: { color: string };
// };
//@ts-ignore
const Stack = createNativeStackNavigator<RootStackParamList>();
export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Home">
        <Stack.Screen name="Home" component={HomeScreen} />
        <Stack.Screen name="ColorSelect" component={ColorSelectScreen} />
        <Stack.Screen name="Confirm" component={ConfirmScreen} />
        <Stack.Screen name="Final" component={FinalScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
