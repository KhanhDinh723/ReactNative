import React, { useState } from "react";
import { View, TouchableOpacity, StyleSheet, Text } from "react-native";
import { NativeStackScreenProps } from "@react-navigation/native-stack";
import { RootStackParamList } from "../App";

type Props = NativeStackScreenProps<RootStackParamList, "ColorSelect">;

export default function ColorSelectScreen ({ navigation }: Props) {
  const [selected, setSelected] = useState<string>("blue");

  return (
    <View style={styles.container}>
      {["blue", "red", "black", "silver"].map((color) => (
        <TouchableOpacity
          key={color}
          style={[
            styles.colorBox,
            { backgroundColor: color },
            selected === color && styles.selected,
          ]}
          onPress={() => setSelected(color)}
        />
      ))}

      <TouchableOpacity
        style={styles.doneButton}
        onPress={() => navigation.navigate("Confirm", { color: selected })}
      >
        <Text style={styles.doneText}>XONG</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: "center", alignItems: "center" },
  colorBox: {
    width: 80,
    height: 80,
    margin: 10,
    borderRadius: 10,
  },
  selected: {
    borderWidth: 3,
    borderColor: "green",
  },
  doneButton: {
    marginTop: 20,
    backgroundColor: "#007bff",
    paddingVertical: 10,
    paddingHorizontal: 30,
    borderRadius: 8,
  },
  doneText: { color: "#fff", fontWeight: "bold" },
});
