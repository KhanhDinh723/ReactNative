import React from "react";
import { View } from "react-native";
import { NativeStackScreenProps } from "@react-navigation/native-stack";
import { RootStackParamList } from "../App";
import PhoneCard from "../components/PhoneCard";

type Props = NativeStackScreenProps<RootStackParamList, "Home">;

export default function HomeScreen({ navigation }: Props) {
  return (
    <View>
      <PhoneCard
      //@ts-ignore
        image={require("../assets/vs_blue.png")}
        title="Điện Thoại Vsmart Joy 3"
        price="1.790.000đ"
        onPress={() => navigation.navigate("ColorSelect")}
      />
    </View>
  );
}
