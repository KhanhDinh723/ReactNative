import React from "react";
import { View, Text, Image, TouchableOpacity, StyleSheet } from "react-native";
import { NativeStackScreenProps } from "@react-navigation/native-stack";
import { RootStackParamList } from "../App";

type Props = NativeStackScreenProps<RootStackParamList, "Final">;

export default function FinalScreen({ route, navigation }: Props) {
  const { color } = route.params;

  const colorImages: Record<string, any> = {
    //@ts-ignore
    blue: require("../assets/vs_blue.png"),
    //@ts-ignore
    red: require("../assets/vs_red.png"),
    //@ts-ignore
    black: require("../assets/vs_black.png"),
    //@ts-ignore
    silver: require("../assets/vs_silver.png"),
  };

  return (
    <View style={{ alignItems: "center", marginTop: 50 }}>
      <Image source={colorImages[color]} style={{ width: 200, height: 300 }} />
      <Text style={{ marginVertical: 10 }}>Màu cuối cùng: {color}</Text>

      <TouchableOpacity
        style={styles.buyButton}
        onPress={() => navigation.navigate("Home")}
      >
        <Text style={styles.buyText}>CHỌN MUA</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  buyButton: {
    marginTop: 20,
    backgroundColor: "#ff5733",
    paddingVertical: 10,
    paddingHorizontal: 30,
    borderRadius: 8,
  },
  buyText: { color: "#fff", fontWeight: "bold" },
});
