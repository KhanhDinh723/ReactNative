import React from "react";
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  StyleSheet,
} from "react-native";

const DATA = [
  { id: "1", name: "iPhone 16", price: 1200 },
  { id: "2", name: "Samsung S25", price: 1000 },
  { id: "3", name: "Xiaomi 15", price: 800 },
];

export default function ProductsScreen({ navigation }: any) {
  return (
    <View style={styles.container}>
      <FlatList
        data={DATA}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={styles.item}
            onPress={() =>
              navigation.navigate("ProductDetails", { id: item.id })
            }
          >
            <Text style={styles.title}>{item.name}</Text>
            <Text style={styles.price}>${item.price}</Text>
          </TouchableOpacity>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20 },
  item: {
    padding: 15,
    marginVertical: 8,
    backgroundColor: "#eee",
    borderRadius: 8,
  },
  title: { fontSize: 18, fontWeight: "bold" },
  price: { color: "green" },
});
