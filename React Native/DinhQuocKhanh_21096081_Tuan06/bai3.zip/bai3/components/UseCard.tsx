import React from "react";
import { View, Text, Image, StyleSheet } from "react-native";

type Props = {
  name: string;
  avatar: string;
};

export default function UserCard({ name, avatar }: Props) {
  return (
    <View style={styles.card}>
      <Image source={{ uri: avatar }} style={styles.avatar} />
      <Text style={styles.name}>{name}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  card: { alignItems: "center" },
  avatar: { width: 100, height: 100, borderRadius: 50, marginBottom: 10 },
  name: { fontSize: 20, fontWeight: "bold" },
});
