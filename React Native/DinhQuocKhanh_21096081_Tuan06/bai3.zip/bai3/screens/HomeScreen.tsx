import React from "react";
import { View, Text, FlatList, TouchableOpacity, StyleSheet } from "react-native";
import { NativeStackScreenProps } from "@react-navigation/native-stack";
import { RootTabParamList } from "../App";

type Props = NativeStackScreenProps<RootTabParamList, "Home">;

const DATA = [
  { id: "1", title: "IPhone 16" },
  { id: "2", title: "Samsung Galaxy S25" },
  { id: "3", title: "Xiaomi 15" },
  { id: "4", title: "Vsmart Joy 3" },
];

export default function HomeScreen({ navigation }: Props) {
  return (
    <View style={styles.container}>
      <FlatList
        data={DATA}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={styles.item}
            onPress={() => navigation.navigate("Search", { keyword: item.title })}
          >
            <Text style={styles.title}>{item.title}</Text>
          </TouchableOpacity>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20 },
  item: {
    padding: 15,
    marginVertical: 8,
    backgroundColor: "#f9c2ff",
    borderRadius: 8,
  },
  title: { fontSize: 18 },
});
