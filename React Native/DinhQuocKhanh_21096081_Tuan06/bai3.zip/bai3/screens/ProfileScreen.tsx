import React from "react";
import { View, StyleSheet } from "react-native";
import UserCard from "../components/UseCard"

export default function ProfileScreen() {
  return (
    <View style={styles.container}>
      <UserCard name="Nguyễn Văn A" avatar="https://i.pravatar.cc/150?img=3" />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: "center", alignItems: "center" },
});
