import React, { useState } from "react";
import { View, TextInput, Text, StyleSheet } from "react-native";
import { NativeStackScreenProps } from "@react-navigation/native-stack";
import { RootTabParamList } from "../App";

type Props = NativeStackScreenProps<RootTabParamList, "Search">;

export default function SearchScreen({ route }: Props) {
  const [keyword, setKeyword] = useState(route.params?.keyword || "");

  return (
    <View style={styles.container}>
      <TextInput
        style={styles.input}
        placeholder="Nhập từ khóa..."
        value={keyword}
        onChangeText={setKeyword}
      />
      <Text style={styles.result}>Từ khóa: {keyword}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20 },
  input: {
    height: 50,
    borderWidth: 1,
    borderColor: "#ccc",
    borderRadius: 8,
    paddingHorizontal: 10,
    marginBottom: 15,
  },
  result: { fontSize: 18 },
});
